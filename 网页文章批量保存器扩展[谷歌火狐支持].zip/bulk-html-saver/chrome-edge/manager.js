(() => {
  const api = globalThis.browser || globalThis.chrome;
  const $ = id => document.getElementById(id);
  const source = $('source');
  const baseInput = $('base');
  const domainInput = $('domain');
  const pathModeInput = $('pathMode');
  const batchInput = $('batch');
  const intervalInput = $('interval');
  const message = $('message');
  const counts = $('counts');
  const progress = $('progress');
  const results = $('results');
  const logs = $('logs');
  const startBtn = $('start');
  const stopBtn = $('stop');
  const extractBtn = $('extract');

  let extracted = [];
  let lastCandidates = [];
  let lastInputMode = 'visual';
  let stopRequested = false;
  let working = false;
  let activeTotal = 0;
  let activeDone = 0;

  function normalizeHost(value) {
    return String(value || '').trim().toLowerCase()
      .replace(/^https?:\/\//i, '').replace(/^\/\//, '').split('/')[0]
      .replace(/:\d+$/, '').replace(/^www\./, '');
  }

  function getBaseUrl() {
    let value = baseInput.value.trim();
    if (!value) {
      const domain = normalizeHost(domainInput.value);
      value = domain ? `https://${domain}/` : 'https://example.com/';
    }
    if (value.startsWith('//')) value = 'https:' + value;
    else if (!/^https?:\/\//i.test(value)) value = 'https://' + value;
    try {
      const url = new URL(value);
      if (!['http:', 'https:'].includes(url.protocol)) throw new Error('invalid protocol');
      return url;
    } catch (_) {
      const domain = normalizeHost(domainInput.value);
      return new URL(`https://${domain || 'example.com'}/`);
    }
  }

  function decodeBasicEntities(value) {
    return String(value || '')
      .replace(/&amp;/gi, '&')
      .replace(/&#0*38;/gi, '&')
      .replace(/&quot;/gi, '"')
      .replace(/&#0*39;|&apos;/gi, "'")
      .replace(/&lt;/gi, '<')
      .replace(/&gt;/gi, '>');
  }

  function isIgnoredScheme(value) {
    return /^(?:javascript:|mailto:|tel:|data:|blob:|about:)/i.test(String(value || '').trim());
  }

  function pushCandidate(out, href, text = '') {
    const raw = decodeBasicEntities(String(href || '').trim()).replace(/^(["'])(.*)\1$/, '$2').trim();
    if (!raw || raw === '#' || raw.startsWith('#') || isIgnoredScheme(raw)) return;
    out.push({ href: raw, text: String(text || '').replace(/\s+/g, ' ').trim() });
  }

  function anchorsFromDocument(doc, out) {
    doc.querySelectorAll('a[href]').forEach(a => {
      pushCandidate(out, a.getAttribute('href') || a.href, a.innerText || a.textContent || a.getAttribute('title') || '');
    });
    // Some themes store click destinations in data attributes rather than ordinary anchors.
    doc.querySelectorAll('[data-href],[data-url]').forEach(el => {
      const value = el.getAttribute('data-href') || el.getAttribute('data-url');
      if (value) pushCandidate(out, value, el.innerText || el.textContent || el.getAttribute('title') || '');
    });
  }

  function rawTextCandidates(text, out) {
    if (!text || !text.trim()) return;
    const raw = text.trim();
    const docsToParse = [raw];

    // Also try a once-decoded variant for HTML source pasted as &lt;a href=...&gt;.
    const decoded = decodeBasicEntities(raw);
    if (decoded !== raw) docsToParse.push(decoded);

    for (const candidateText of docsToParse) {
      try {
        const doc = new DOMParser().parseFromString(candidateText, 'text/html');
        anchorsFromDocument(doc, out);
      } catch (_) {}

      // Tolerant href parser: quoted and unquoted values, including code fragments.
      const hrefRegex = /\b(?:href|data-href|data-url)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'<>`]+))/gi;
      let match;
      while ((match = hrefRegex.exec(candidateText)) !== null) {
        pushCandidate(out, match[1] || match[2] || match[3], '');
      }

      // Markdown links, e.g. [title](/post/123.html "title").
      const markdownRegex = /\[([^\]]+)\]\(\s*(?:<([^>]+)>|([^\s)]+))(?:\s+"([^"]*)")?\s*\)/g;
      while ((match = markdownRegex.exec(candidateText)) !== null) {
        const target = match[2] || match[3];
        if (target) pushCandidate(out, target, match[1] || match[4] || '');
      }

      // Full URLs copied from web pages or plain text lists.
      const urlRegex = /https?:\/\/[^\s<>"'`\])}]+/gi;
      while ((match = urlRegex.exec(candidateText)) !== null) {
        pushCandidate(out, match[0].replace(/[.,;!?，。；！？]+$/g, ''), '');
      }

      // Standalone relative article paths/filenames; avoid guessing ordinary words.
      for (const line of candidateText.split(/\r?\n/)) {
        const token = line.trim().replace(/^[-*\s]+/, '').replace(/^['"]|['"]$/g, '');
        if (!token || token.length > 500 || /\s/.test(token)) continue;
        if (/^(?:\/|\.\/|\.\.\/)[^\s<>"']+\.html?(?:[?#][^\s]*)?$/i.test(token) ||
            /^[\w.-]+\.html?(?:[?#][^\s]*)?$/i.test(token)) {
          pushCandidate(out, token, '');
        }
      }
    }
  }

  function collectVisualCandidates() {
    const out = [];
    anchorsFromDocument(source, out);
    const text = source.innerText || source.textContent || '';
    rawTextCandidates(text, out);
    return out;
  }

  function collectSourceCandidates() {
    const out = [];
    rawTextCandidates($('sourceHtml').value || '', out);
    return out;
  }

  function getRules() {
    return {
      domain: normalizeHost(domainInput.value),
      mode: pathModeInput.value,
      sameDomain: $('sameDomain').checked,
      skipMedia: $('skipMedia').checked,
      dedupe: $('dedupe').checked
    };
  }

  function isMediaUrl(url) {
    return /\.(?:jpe?g|png|gif|webp|avif|svg|ico|bmp|tiff?|mp4|m4v|mov|avi|webm|mp3|m4a|wav|ogg|flac|pdf|zip|rar|7z|gz|tar|bz2|xz|css|m?js|woff2?|ttf|otf|eot|apk|exe|dmg)(?:$|[?#])/i.test(url);
  }

  function filterCandidates(candidates) {
    const rules = getRules();
    const output = [];
    const seen = new Set();
    let rejected = 0;
    for (const candidate of candidates) {
      const raw = String(candidate.href || '').trim();
      if (!raw || raw.startsWith('#') || isIgnoredScheme(raw)) { rejected++; continue; }
      let url;
      try { url = new URL(raw, getBaseUrl().href); } catch (_) { rejected++; continue; }
      if (!['http:', 'https:'].includes(url.protocol)) { rejected++; continue; }
      url.hash = '';
      const host = normalizeHost(url.hostname);
      const domain = rules.domain;
      const shouldFilterDomain = rules.mode !== 'all-any' && rules.sameDomain && Boolean(domain);
      if (shouldFilterDomain && !(host === domain || host.endsWith('.' + domain))) { rejected++; continue; }
      if (rules.mode === 'html' && !/\.html?$/i.test(url.pathname)) { rejected++; continue; }
      if (rules.skipMedia && isMediaUrl(url.href)) { rejected++; continue; }
      const href = url.href;
      const key = rules.dedupe ? href : `${href}::${output.length}`;
      if (seen.has(key)) { rejected++; continue; }
      seen.add(key);
      output.push({ url: href, text: candidate.text || '' });
    }
    extracted = output;
    renderResults();
    $('inputStatus').innerHTML = `<span class="pill good">解析完成</span>收集到 ${candidates.length} 个候选链接，筛选后保留 <strong>${output.length}</strong> 个，过滤或重复 ${rejected} 个。`;
    activeTotal = 0;
    activeDone = 0;
    updateCounts(0, 0);
    message.textContent = output.length ? '链接提取完成。请检查勾选结果，再开始批量保存。' : '没有提取到符合条件的链接。可切换 HTML 源码模式，或放宽域名/链接类型筛选。';
  }

  function parseVisual() {
    lastInputMode = 'visual';
    lastCandidates = collectVisualCandidates();
    filterCandidates(lastCandidates);
  }

  function parseSource() {
    lastInputMode = 'source';
    lastCandidates = collectSourceCandidates();
    filterCandidates(lastCandidates);
  }

  function applyCurrentFilter() {
    if (lastCandidates.length) {
      filterCandidates(lastCandidates);
      return;
    }
    const sourceVisible = $('sourcePanel').classList.contains('show');
    if (sourceVisible && $('sourceHtml').value.trim()) parseSource();
    else parseVisual();
  }

  function renderResults() {
    results.innerHTML = '';
    if (!extracted.length) {
      const empty = document.createElement('div');
      empty.className = 'item';
      empty.style.color = 'var(--muted)';
      empty.textContent = '暂无结果。请确认剪贴板保留了链接，或通过 HTML 源码模式提取。';
      results.appendChild(empty);
      $('resultStatus').textContent = '共 0 个结果。';
      return;
    }
    extracted.forEach((item, index) => {
      const row = document.createElement('label');
      row.className = 'item';
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = true;
      checkbox.className = 'result-check';
      checkbox.dataset.index = String(index);
      const number = document.createElement('span');
      number.className = 'num';
      number.textContent = `${index + 1}.`;
      const main = document.createElement('span');
      main.className = 'item-main';
      const title = document.createElement('span');
      title.className = 'item-title';
      title.textContent = item.text || '(未识别到标题)';
      const urlLine = document.createElement('span');
      urlLine.className = 'url';
      const link = document.createElement('a');
      link.href = item.url;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = item.url;
      urlLine.appendChild(link);
      main.append(title, urlLine);
      row.append(checkbox, number, main);
      results.appendChild(row);
    });
    $('resultStatus').textContent = `共提取 ${extracted.length} 个链接，默认全选。请取消不需要保存的项目。`;
  }

  function checkedItems() {
    return Array.from(document.querySelectorAll('.result-check:checked'))
      .map(box => extracted[Number(box.dataset.index)])
      .filter(Boolean);
  }

  function updateCounts(done, total = activeTotal || extracted.length) {
    counts.textContent = `本轮 ${total} 个待保存，已处理 ${done} 个，剩余 ${Math.max(0, total - done)} 个。`;
    progress.style.width = (total ? Math.min(100, done / total * 100) : 0) + '%';
  }

  function logResult(text, ok) {
    const line = document.createElement('div');
    line.className = ok ? 'ok' : 'err';
    line.textContent = text;
    logs.appendChild(line);
    logs.scrollTop = logs.scrollHeight;
  }

  function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

  function waitForNavigation(tabId, url, timeoutMs = 90000) {
    return new Promise((resolve, reject) => {
      let settled = false;
      const cleanup = () => {
        api.tabs.onUpdated.removeListener(onUpdated);
        clearTimeout(timer);
      };
      const finish = (fn, value) => {
        if (settled) return;
        settled = true;
        cleanup();
        fn(value);
      };
      const onUpdated = (changedId, info, tab) => {
        if (changedId === tabId && info.status === 'complete') finish(resolve, tab || { id: tabId, url });
      };
      const timer = setTimeout(() => finish(reject, new Error('页面加载超时（90 秒）')), timeoutMs);
      api.tabs.onUpdated.addListener(onUpdated);
      Promise.resolve(api.tabs.update(tabId, { url })).catch(err => finish(reject, err));
    });
  }

  function safeFilename(value) {
    return String(value || '网页').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_')
      .replace(/[. ]+$/g, '').replace(/\s+/g, ' ').trim().slice(0, 100) || '网页';
  }

  async function getHtml(tabId) {
    const injected = await api.scripting.executeScript({
      target: { tabId },
      func: () => {
        const d = document.doctype;
        let doctype = '';
        if (d) {
          doctype = '<!DOCTYPE ' + d.name;
          if (d.publicId) doctype += ' PUBLIC "' + d.publicId + '"';
          if (d.systemId) doctype += (d.publicId ? ' ' : ' SYSTEM ') + '"' + d.systemId + '"';
          doctype += '>\n';
        }
        return {
          title: document.title || location.hostname,
          url: location.href,
          html: doctype + (document.documentElement ? document.documentElement.outerHTML : '')
        };
      }
    });
    const result = injected && injected[0] && injected[0].result;
    if (!result || !result.html) throw new Error('无法读取网页 HTML');
    return result;
  }

  async function saveHtml(html, filename) {
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const objectUrl = URL.createObjectURL(blob);
    try {
      return await api.downloads.download({
        url: objectUrl,
        filename,
        conflictAction: 'uniquify',
        saveAs: false
      });
    } finally {
      setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
    }
  }

  async function requestHostAccess(urls) {
    const origins = [...new Set(urls.map(value => {
      const url = new URL(value);
      return url.origin + '/*';
    }))];
    const permitted = await api.permissions.request({ origins });
    if (!permitted) throw new Error('未获得网站访问授权，已取消任务。');
  }

  async function startBatch() {
    if (working) return;
    // Do not silently replace the user's checked list; extract first if no result exists.
    if (!extracted.length) {
      if ($('sourcePanel').classList.contains('show') && $('sourceHtml').value.trim()) parseSource();
      else parseVisual();
      if (extracted.length) message.textContent = '已提取链接。请检查勾选列表，再次点击“批量保存 HTML”开始保存。';
      return;
    }

    const queue = checkedItems();
    if (!queue.length) {
      message.textContent = '没有勾选任何链接，请先在提取结果中勾选要保存的文章。';
      return;
    }

    working = true;
    stopRequested = false;
    activeTotal = queue.length;
    activeDone = 0;
    startBtn.disabled = true;
    extractBtn.disabled = true;
    stopBtn.disabled = false;
    $('applyFilter').disabled = true;
    $('logs').innerHTML = '';
    updateCounts(0, activeTotal);
    let saved = 0;
    let failed = 0;
    let tempTabId = null;
    try {
      message.textContent = '正在申请访问所选链接所在网站的权限……';
      await requestHostAccess(queue.map(item => item.url));
      const created = await api.tabs.create({ url: 'about:blank', active: false });
      tempTabId = created.id;
      const batchSize = Math.max(1, Number(batchInput.value) || 5);
      const intervalMs = Math.max(0, Number(intervalInput.value) || 1000);

      for (let i = 0; i < queue.length; i++) {
        if (stopRequested) break;
        const item = queue[i];
        message.textContent = `正在保存第 ${i + 1}/${queue.length} 个：${item.url}`;
        try {
          await waitForNavigation(tempTabId, item.url);
          await delay(350);
          const page = await getHtml(tempTabId);
          const hostname = new URL(page.url || item.url).hostname;
          const title = safeFilename(page.title || item.text || hostname);
          const filename = `批量保存网页/${String(i + 1).padStart(3, '0')}_${title}.html`;
          await saveHtml(page.html, filename);
          saved++;
          logResult(`✓ 已发起保存：${filename}`, true);
        } catch (error) {
          failed++;
          logResult(`✗ 保存失败：${item.url}；${error && error.message ? error.message : String(error)}`, false);
        }
        activeDone++;
        updateCounts(activeDone, activeTotal);
        if (stopRequested) break;
        // Small pacing within a batch, with the configurable interval between batches.
        if (i < queue.length - 1) {
          const atBatchBoundary = (i + 1) % batchSize === 0;
          if (atBatchBoundary) {
            message.textContent = `已处理 ${activeDone}/${queue.length} 个，批次间歇中……`;
            await delay(intervalMs);
          } else {
            await delay(300);
          }
        }
      }
    } catch (error) {
      message.textContent = `任务未能启动：${error && error.message ? error.message : String(error)}`;
      logResult(`✗ ${message.textContent}`, false);
    } finally {
      if (tempTabId != null) {
        try { await api.tabs.remove(tempTabId); } catch (_) {}
      }
      working = false;
      startBtn.disabled = false;
      extractBtn.disabled = false;
      stopBtn.disabled = true;
      $('applyFilter').disabled = false;
      if (stopRequested) message.textContent = `已停止队列：成功保存 ${saved} 个，失败 ${failed} 个，已处理 ${activeDone}/${activeTotal} 个。`;
      else if (activeDone === activeTotal) message.textContent = `任务完成：成功保存 ${saved} 个 HTML，失败 ${failed} 个。`;
      updateCounts(activeDone, activeTotal);
    }
  }

  $('extract').addEventListener('click', () => {
    if ($('sourcePanel').classList.contains('show') && $('sourceHtml').value.trim()) parseSource();
    else parseVisual();
  });

  $('toggleSource').addEventListener('click', () => $('sourcePanel').classList.toggle('show'));
  $('extractSource').addEventListener('click', parseSource);
  $('loadSourceVisual').addEventListener('click', () => {
    const doc = new DOMParser().parseFromString($('sourceHtml').value || '', 'text/html');
    // Sanitize active content before putting pasted source into the live editor.
    doc.querySelectorAll('script,iframe,object,embed,base,form').forEach(el => el.remove());
    doc.querySelectorAll('*').forEach(el => {
      for (const attr of [...el.attributes]) {
        if (/^on/i.test(attr.name)) el.removeAttribute(attr.name);
        else if (['href', 'src', 'xlink:href', 'action'].includes(attr.name.toLowerCase()) && /^\s*javascript:/i.test(attr.value)) el.removeAttribute(attr.name);
      }
    });
    source.innerHTML = doc.body.innerHTML;
    $('sourcePanel').classList.remove('show');
    $('inputStatus').textContent = '源码已载入富文本预览。点击“提取链接”读取其中的 href。';
  });
  $('selectAllEditor').addEventListener('click', () => {
    source.focus();
    const range = document.createRange();
    range.selectNodeContents(source);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
  });
  $('clearEditor').addEventListener('click', () => {
    source.innerHTML = '';
    $('inputStatus').textContent = '富文本编辑区已清空。';
  });
  $('applyFilter').addEventListener('click', applyCurrentFilter);
  $('checkAll').addEventListener('click', () => {
    document.querySelectorAll('.result-check').forEach(box => box.checked = true);
    $('resultStatus').textContent = `已全选 ${checkedItems().length} 个链接。`;
  });
  $('checkNone').addEventListener('click', () => {
    document.querySelectorAll('.result-check').forEach(box => box.checked = false);
    $('resultStatus').textContent = '已取消全部选择。';
  });
  $('copyUrls').addEventListener('click', async () => {
    const text = checkedItems().map(item => item.url).join('\n');
    if (!text) { $('resultStatus').textContent = '请先勾选至少一个链接。'; return; }
    try {
      await navigator.clipboard.writeText(text);
      $('resultStatus').textContent = `已复制 ${checkedItems().length} 个链接。`;
    } catch (_) {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      const ok = document.execCommand('copy');
      textarea.remove();
      $('resultStatus').textContent = ok ? '链接已复制。' : '复制失败，请手动复制链接。';
    }
  });
  $('downloadTxt').addEventListener('click', () => {
    const text = checkedItems().map(item => item.url).join('\n');
    if (!text) { $('resultStatus').textContent = '请先勾选至少一个链接。'; return; }
    const blob = new Blob(['\ufeff' + text], { type: 'text/plain;charset=utf-8' });
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = objectUrl;
    anchor.download = '提取的链接.txt';
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  });

  startBtn.addEventListener('click', startBatch);
  stopBtn.addEventListener('click', () => {
    stopRequested = true;
    stopBtn.disabled = true;
    message.textContent = '已请求停止，将在当前网页处理结束后停止。';
  });
  $('resetProgress').addEventListener('click', () => {
    if (working) return;
    activeTotal = 0;
    activeDone = 0;
    updateCounts(0, 0);
    message.textContent = '处理进度已重置。此操作不会删除已下载的文件。';
  });
  $('clear').addEventListener('click', () => {
    if (working) return;
    source.innerHTML = '';
    $('sourceHtml').value = '';
    extracted = [];
    lastCandidates = [];
    results.innerHTML = '';
    logs.innerHTML = '';
    $('inputStatus').textContent = '已清空，等待粘贴内容。';
    $('resultStatus').textContent = '提取结果将在这里显示。';
    activeTotal = 0;
    activeDone = 0;
    updateCounts(0, 0);
    message.textContent = '已清空，等待新内容。';
  });
  source.addEventListener('paste', () => setTimeout(() => {
    if (!working) $('inputStatus').textContent = '内容已粘贴。点击“提取链接”读取隐藏 href。';
  }, 100));
  $('sourceHtml').addEventListener('paste', () => setTimeout(() => {
    if (!working) $('inputStatus').textContent = '源码已粘贴。点击“从 HTML 源码提取”。';
  }, 20));
  source.addEventListener('keydown', event => {
    if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
      event.preventDefault();
      parseVisual();
    }
  });

})();
